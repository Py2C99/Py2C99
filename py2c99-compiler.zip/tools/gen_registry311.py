"""Generate runtime/pyrt_311.c from the running CPython 3.11.

The Py2C99 runtime needs two exhaustive tables:

* every name exported by ``builtins`` in Python 3.11 (158 names), and
* every name in ``sys.stdlib_module_names`` (305 modules).

Keeping them in sync by hand is error prone, so this script regenerates the C
registry from the interpreter that Py2C99 targets.  Run it whenever the target
Python version changes:

    python tools/gen_registry311.py

The generated file is checked in so that the compiler never needs Python 3.11
at build time; CPython is only needed by the transpiler itself.
"""
import builtins
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "runtime" / "pyrt_311.c"

if sys.version_info[:2] != (3, 11):
    raise SystemExit("gen_registry311.py must run under Python 3.11 "
                     "(found %d.%d)" % sys.version_info[:2])

BUILTIN_NAMES = sorted(dir(builtins))
STDLIB_MODULES = sorted(sys.stdlib_module_names)
EXCEPTION_NAMES = sorted(
    name for name in BUILTIN_NAMES
    if isinstance(getattr(builtins, name), type)
    and issubclass(getattr(builtins, name), BaseException)
)

# Private extension modules are implementation details of their public
# counterparts.  Mapping them lets ``import _json`` behave like ``import json``.
ALIASES = {}
for _name in STDLIB_MODULES:
    if _name.startswith("_"):
        _plain = _name[1:]
        if _plain in STDLIB_MODULES and _plain != _name:
            ALIASES[_name] = _plain

ALIASES.update({
    "_py_abc": "abc", "_sitebuiltins": "site", "_frozen_importlib": "importlib",
    "_frozen_importlib_external": "importlib", "_compat_pickle": "pickle",
    "_compression": "bz2", "_markupbase": "html.parser",
    "_osx_support": "sysconfig", "_bootsubprocess": "subprocess",
    "_lsprof": "cProfile", "_overlapped": "asyncio",
    "_posixshmem": "multiprocessing", "_posixsubprocess": "subprocess",
    "_pyio": "io", "_pydecimal": "decimal", "_scproxy": "urllib.request",
    "_sre": "re", "_tkinter": "tkinter", "_winapi": "msvcrt",
    "_multibytecodec": "codecs", "_codecs_cn": "codecs",
    "_codecs_hk": "codecs", "_codecs_iso2022": "codecs",
    "_codecs_jp": "codecs", "_codecs_kr": "codecs", "_codecs_tw": "codecs",
    "_thread": "threading", "_threading_local": "threading",
    "_weakrefset": "weakref", "_imp": "importlib", "_ast": "ast",
    "_collections": "collections", "_collections_abc": "collections",
    "_ssl": "ssl", "_crypt": "crypt", "_dbm": "dbm", "_gdbm": "dbm",
    "_elementtree": "xml.etree.ElementTree", "_md5": "hashlib",
    "_sha1": "hashlib", "_sha256": "hashlib", "_sha3": "hashlib",
    "_sha512": "hashlib", "_blake2": "hashlib", "_strptime": "datetime",
    "_zoneinfo": "zoneinfo", "_random": "random", "_statistics": "statistics",
    "_queue": "queue", "_locale": "locale", "_struct": "struct",
    "_operator": "operator", "_functools": "functools", "_heapq": "heapq",
    "_bisect": "bisect", "_signal": "signal", "_socket": "socket",
    "_json": "json", "_csv": "csv", "_pickle": "pickle", "_io": "io",
    "_opcode": "opcode", "_symtable": "symtable", "_tokenize": "tokenize",
    "_typing": "typing", "_uuid": "uuid", "_warnings": "warnings",
    "_weakref": "weakref", "_datetime": "datetime", "_decimal": "decimal",
    "_contextvars": "contextvars", "_codecs": "codecs",
    "_tracemalloc": "tracemalloc", "_asyncio": "asyncio",
    "_ctypes": "ctypes", "_curses": "curses", "_curses_panel": "curses",
    "_bz2": "bz2", "_lzma": "lzma", "_sqlite3": "sqlite3",
    "_msi": "msilib", "_sre": "re",
})

ZEN = """The Zen of Python, by Tim Peters

Beautiful is better than ugly.
Explicit is better than implicit.
Simple is better than complex.
Complex is better than complicated.
Flat is better than nested.
Sparse is better than dense.
Readability counts.
Special cases aren't special enough to break the rules.
Although practicality beats purity.
Errors should never pass silently.
Unless explicitly silenced.
In the face of ambiguity, refuse the temptation to guess.
There should be one-- and preferably only one --obvious way to do it.
Although that way may not be obvious at first unless you're Dutch.
Now is better than never.
Although never is often better than *right* now.
If the implementation is hard to explain, it's a bad idea.
If the implementation is easy to explain, it may be a good idea.
Namespaces are one honking great idea -- let's do more of those!"""


def c_array(name, values, indent="    "):
    """Emit the body of an already-declared C array (template owns the header)."""
    return "\n".join(indent + ", ".join(values[i:i + 6]) + ","
                     for i in range(0, len(values), 6))


def c_string(text):
    """Escape a Python string as a C string literal (UTF-8 source bytes)."""
    out = []
    for ch in text:
        if ch == "\\":
            out.append("\\\\")
        elif ch == '"':
            out.append('\\"')
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif ord(ch) < 32 or ord(ch) > 126:
            out.append("\\x%02X" % ord(ch))  # ASCII-only 3.11 names/zen
        else:
            out.append(ch)
    return '"' + "".join(out) + '"'


BODY = r'''/*
 * GENERATED FILE - do not edit by hand.
 * Regenerate with: python tools/gen_registry311.py  (under Python 3.11)
 *
 * Exhaustive Python 3.11 builtin / stdlib name registries and the compatibility
 * layer that makes every stdlib module name importable in compiled mode.
 */
#define _CRT_SECURE_NO_WARNINGS
#include "pyrt.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int e311(const char *a, const char *b) { return a && b && !strcmp(a, b); }

/* Every name in dir(builtins) for CPython 3.11. */
static const char *const B311[] = {
@@BUILTINS@@
};

/* Every name in sys.stdlib_module_names for CPython 3.11. */
static const char *const M311[] = {
@@MODULES@@
};

/* Private/implementation-detail modules mapped to their public module. */
static const struct { const char *from; const char *to; } A311[] = {
@@ALIASES@@
};

/* Exception names are callable classes, not ordinary functions. */
static const char *const E311[] = {
@@EXCEPTIONS@@
};

const char *py311_canonical_module(const char *module) {
    size_t i;
    if (!module) return "";
    for (i = 0; i < sizeof(A311) / sizeof(A311[0]); i++)
        if (e311(module, A311[i].from)) return A311[i].to;
    return module;
}

int py311_is_builtin(const char *name) {
    size_t i;
    if (!name) return 0;
    for (i = 0; i < sizeof(B311) / sizeof(B311[0]); i++)
        if (e311(name, B311[i])) return 1;
    return 0;
}

int py311_is_stdlib_module(const char *module) {
    const char *m = py311_canonical_module(module);
    size_t i, n;
    if (!m || !*m) return 0;
    n = strlen(m);
    for (i = 0; i < sizeof(M311) / sizeof(M311[0]); i++) {
        size_t k = strlen(M311[i]);
        if (e311(m, M311[i])) return 1;
        /* Submodules such as concurrent.futures or email.message are part of
           the stdlib even though sys.stdlib_module_names lists packages. */
        if (n > k + 1 && m[k] == '.' && !strncmp(m, M311[i], k)) return 1;
    }
    return 0;
}

PyVal *py311_builtin_names(void) {
    PyVal *out = py_list_new(), *s;
    size_t i;
    for (i = 0; i < sizeof(B311) / sizeof(B311[0]); i++) {
        s = py_str(B311[i]);
        py_list_append(out, s);
        py_release(s);
    }
    return out;
}

PyVal *py311_module_names(void) {
    PyVal *out = py_list_new(), *s;
    size_t i;
    for (i = 0; i < sizeof(M311) / sizeof(M311[0]); i++) {
        s = py_str(M311[i]);
        py_list_append(out, s);
        py_release(s);
    }
    return out;
}

/* ------------------------------------------------ builtins not in core tables */

static PyVal *b311_complex(PyVal **a, size_t n, PyVal *kw) {
    PyVal *d = py_dict_new();
    PyVal *real = n > 0 ? a[0] : py_int(0);
    PyVal *imag = n > 1 ? a[1] : (kw ? py_kw_get(kw, "imag") : NULL);
    (void)kw;
    py_dict_put(d, "__name__", py_str("complex"));
    py_dict_put(d, "real", py_float(py_as_float(real)));
    py_dict_put(d, "imag", py_float(imag ? py_as_float(imag) : 0.0));
    return d;
}

static PyVal *b311_build_class(PyVal **a, size_t n, PyVal *kw) {
    const char *name = n > 1 ? py_cstr(a[1]) : "object";
    (void)kw;
    return py_class(py_dict_new(), name ? name : "object");
}

static PyVal *b311_copyright(PyVal **a, size_t n, PyVal *kw) {
    (void)a; (void)n; (void)kw;
    fputs("Python 3.11 (py2c99 compiled mode) - no CPython is embedded.\n", stdout);
    return py_none();
}

static PyVal *b311_credits(PyVal **a, size_t n, PyVal *kw) {
    (void)a; (void)n; (void)kw;
    fputs("Thanks to the Python software foundation and the py2c99 contributors.\n", stdout);
    return py_none();
}

static PyVal *b311_license(PyVal **a, size_t n, PyVal *kw) {
    (void)a; (void)n; (void)kw;
    fputs("py2c99 generated programs are distributed under the PSF license.\n", stdout);
    return py_none();
}

/* Constants and exception classes are values, not functions.  pyrt.c checks
   this table before pyrt_builtins.c so that builtins.__debug__ is True rather
   than the legacy helper function of the same name. */
PyVal *py311_builtin_const(const char *name) {
    size_t i;
    if (!name) return NULL;
    if (e311(name, "None")) return py_none();
    if (e311(name, "True")) return py_bool(1);
    if (e311(name, "False")) return py_bool(0);
    if (e311(name, "Ellipsis")) return py_str("Ellipsis");
    if (e311(name, "NotImplemented")) return py_str("NotImplemented");
    if (e311(name, "__debug__")) return py_bool(1);
    if (e311(name, "__name__") || e311(name, "__package__"))
        return py_str("builtins");
    if (e311(name, "__doc__")) return py_none();
    if (e311(name, "__loader__") || e311(name, "__spec__"))
        return py_str("py2c99");
    for (i = 0; i < sizeof(E311) / sizeof(E311[0]); i++) {
        if (!e311(name, E311[i])) continue;
        {
            PyVal *cls = py_exc_class(name);
            if (cls) return cls;
            return py_class(py_dict_new(), name);
        }
    }
    return NULL;
}

/* Return a new reference for a builtin that pyrt.c / pyrt_builtins.c do not
   provide (the remaining callables). */
PyVal *py311_builtin_get(const char *name) {
    PyVal *constant = py311_builtin_const(name);
    if (constant) return constant;
    if (!name) return NULL;
    if (e311(name, "complex")) return py_func(b311_complex, "complex");
    if (e311(name, "__build_class__"))
        return py_func(b311_build_class, "__build_class__");
    if (e311(name, "copyright")) return py_func(b311_copyright, "copyright");
    if (e311(name, "credits")) return py_func(b311_credits, "credits");
    if (e311(name, "license")) return py_func(b311_license, "license");
    return NULL;
}

/* ----------------------------------------------------------- module constants */

static const char *const FUTURE_FEATURES[] = {
    "nested_scopes", "generators", "division", "absolute_import",
    "with_statement", "print_function", "unicode_literals",
    "generator_stop", "annotations", NULL
};

PyVal *py311_module_const(const char *module, const char *name) {
    size_t i;
    if (!module || !name) return NULL;
    if (e311(module, "__future__")) {
        for (i = 0; FUTURE_FEATURES[i]; i++)
            if (e311(name, FUTURE_FEATURES[i])) return py_str(name);
        if (e311(name, "all_features")) {
            PyVal *out = py_list_new(), *s;
            for (i = 0; FUTURE_FEATURES[i]; i++) {
                s = py_str(FUTURE_FEATURES[i]);
                py_list_append(out, s);
                py_release(s);
            }
            return out;
        }
    }
    if (e311(module, "this") && e311(name, "s")) return py_str(@@ZEN@@);
    if (e311(module, "sys") && e311(name, "stdlib_module_names"))
        return py311_module_names();
    if (e311(module, "sys") && e311(name, "builtin_module_names"))
        return py311_builtin_names();
    return NULL;
}

/* ------------------------------------------------------------- module functions */

static PyVal *m311_url2path(PyVal **a, size_t n, PyVal *kw) {
    const char *s = n ? py_cstr(a[0]) : "";
    char *out, *p;
    PyVal *r;
    size_t i;
    (void)kw;
    out = (char *)malloc((s ? strlen(s) : 0) + 1);
    if (!out) return py_str("");
    p = out;
    for (i = 0; s && s[i]; i++) {
        if (s[i] == '%' && s[i + 1] && s[i + 2]) {
            unsigned int v = 0;
            if (sscanf(s + i + 1, "%2x", &v) == 1) {
                *p++ = (char)(unsigned char)v;
                i += 2;
                continue;
            }
        }
        *p++ = s[i] == '/' ? '\\' : s[i];
    }
    *p = 0;
    r = py_str(out);
    free(out);
    return r;
}

static PyVal *m311_path2url(PyVal **a, size_t n, PyVal *kw) {
    const char *s = n ? py_cstr(a[0]) : "";
    char *out;
    PyVal *r;
    size_t i, j = 0;
    (void)kw;
    out = (char *)malloc((s ? strlen(s) : 0) * 3 + 2);
    if (!out) return py_str("");
    for (i = 0; s && s[i]; i++) {
        if (s[i] == '\\') out[j++] = '/';
        else out[j++] = s[i];
    }
    out[j] = 0;
    r = py_str(out);
    free(out);
    return r;
}

static PyVal *m311_quote(PyVal **a, size_t n, PyVal *kw) {
    const char *s = n ? py_cstr(a[0]) : "";
    char *out;
    PyVal *r;
    size_t i, j = 0;
    (void)kw;
    out = (char *)malloc((s ? strlen(s) : 0) * 2 + 3);
    if (!out) return py_str("");
    out[j++] = '\'';
    for (i = 0; s && s[i]; i++) {
        if (s[i] == '\'') out[j++] = '\\';
        out[j++] = s[i];
    }
    out[j++] = '\'';
    out[j] = 0;
    r = py_str(out);
    free(out);
    return r;
}

static int ip4_octets(const char *s, int *out) {
    int i;
    const char *p = s;
    for (i = 0; i < 4; i++) {
        char *end = NULL;
        long v;
        if (!p || !*p) return 0;
        v = strtol(p, &end, 10);
        if (end == p || v < 0 || v > 255) return 0;
        out[i] = (int)v;
        p = end;
        if (i < 3) {
            if (*p != '.') return 0;
            p++;
        } else if (*p) return 0;
    }
    return 1;
}

static PyVal *m311_ip(PyVal **a, size_t n, PyVal *kw) {
    const char *s = n ? py_cstr(a[0]) : "";
    int o[4];
    PyVal *d;
    (void)kw;
    if (!s || !ip4_octets(s, o)) {
        py_raise(PY_EXC_VALUE, "invalid IPv4 address");
        return py_none();
    }
    d = py_dict_new();
    py_dict_put(d, "__name__", py_str("IPv4Address"));
    py_dict_put(d, "compressed", py_str(s));
    py_dict_put(d, "version", py_int(4));
    return d;
}

static PyVal *m311_noop(PyVal **a, size_t n, PyVal *kw) {
    (void)a; (void)n; (void)kw;
    return py_none();
}

/* gzip uses the pure-C deflate stored blocks already implemented by zlib. */
static uint32_t crc32_311(const unsigned char *s, size_t n) {
    uint32_t crc = 0xFFFFFFFFu;
    size_t i;
    int k;
    for (i = 0; i < n; i++) {
        crc ^= s[i];
        for (k = 0; k < 8; k++)
            crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
    return crc ^ 0xFFFFFFFFu;
}

static PyVal *m311_gzip_compress(PyVal **a, size_t n, PyVal *kw) {
    PyVal *data = n ? a[0] : py_str("");
    PyVal *argv[1], *z, *out;
    const char *s = py_cstr(data);
    size_t len = py_cstr_len(data), zlen, i;
    uint32_t crc;
    unsigned char *buf;
    (void)kw;
    argv[0] = data;
    z = py_module_call("zlib", "compress", argv, 1, NULL);
    zlen = py_cstr_len(z);
    crc = crc32_311((const unsigned char *)s, len);
    buf = (unsigned char *)malloc(10 + zlen + 8);
    if (!buf) { py_release(z); return py_str(""); }
    buf[0] = 0x1f; buf[1] = 0x8b; buf[2] = 8; buf[3] = 0;
    for (i = 4; i < 9; i++) buf[i] = 0;
    buf[9] = 0xff;
    memcpy(buf + 10, py_cstr(z), zlen);
    for (i = 0; i < 4; i++) buf[10 + zlen + i] = (unsigned char)(crc >> (8 * i));
    for (i = 0; i < 4; i++) buf[14 + zlen + i] = (unsigned char)(len >> (8 * i));
    out = py_strn((const char *)buf, 10 + zlen + 8);
    free(buf);
    py_release(z);
    return out;
}

static PyVal *m311_gzip_decompress(PyVal **a, size_t n, PyVal *kw) {
    PyVal *data = n ? a[0] : py_str("");
    const char *s = py_cstr(data);
    size_t len = py_cstr_len(data);
    PyVal *part, *argv[1], *out;
    (void)kw;
    if (len < 18 || (unsigned char)s[0] != 0x1f ||
        (unsigned char)s[1] != 0x8b || (unsigned char)s[2] != 8) {
        py_raise(PY_EXC_VALUE, "invalid gzip stream");
        return py_none();
    }
    part = py_strn(s + 10, len - 18);
    argv[0] = part;
    out = py_module_call("zlib", "decompress", argv, 1, NULL);
    py_release(part);
    return out;
}

static PyVal *m311_capwords(PyVal **a, size_t n, PyVal *kw) {
    PyVal *words, *item = NULL, *out, *sep = py_str(" ");
    PyVal *cap = py_list_new(), *args[1];
    size_t i, count;
    (void)kw;
    words = py_method(n ? a[0] : py_str(""), "split", NULL, 0, NULL);
    count = py_len(words);
    for (i = 0; i < count; i++) {
        item = py_getitem(words, py_int((int64_t)i));
        py_list_append(cap, py_method(item, "capitalize", NULL, 0, NULL));
        py_release(item);
    }
    args[0] = cap;
    out = py_method(sep, "join", args, 1, NULL);
    py_release(cap);
    py_release(sep);
    py_release(words);
    return out;
}

/* ------------------------------------------------------------- argparse */

static PyVal *ap_add_argument(PyVal **a, size_t n, PyVal *kw) {
    PyVal *self = n ? a[0] : py_none();
    PyVal *opts = py_getattr(self, "options");
    PyVal *spec = py_dict_new(), *name = NULL, *action, *type, *defval;
    size_t i;
    for (i = 1; i < n; i++) {
        PyVal *s = py_str_of(a[i]);
        if (py_cstr(s) && py_cstr(s)[0] == '-') name = s;
        else py_release(s);
    }
    if (!name) {
        py_raise(PY_EXC_VALUE, "add_argument() requires an option string");
        py_release(spec); py_release(opts);
        return py_none();
    }
    action = kw ? py_kw_get(kw, "action") : NULL;
    type = kw ? py_kw_get(kw, "type") : NULL;
    defval = kw ? py_kw_get(kw, "default") : NULL;
    py_dict_put(spec, "name", name);
    py_dict_put(spec, "action", action ? action : py_str("store"));
    py_dict_put(spec, "type", type ? type : py_str("str"));
    py_dict_put(spec, "default", defval ? defval
                : (action && py_cstr(action) &&
                   !strcmp(py_cstr(action), "store_true") ? py_bool(0)
                                                          : py_str("")));
    py_list_append(opts, spec);
    py_setattr(self, "options", opts);
    py_release(spec); py_release(opts); py_release(name);
    /* py_kw_get() borrows; py_dict_put() has already retained these. */
    return py_none();
}

static PyVal *ap_parse_args(PyVal **a, size_t n, PyVal *kw) {
    PyVal *self = n ? a[0] : py_none();
    PyVal *opts = py_getattr(self, "options");
    PyVal *argv = (n > 1 && a[1]) ? a[1] : py_sys_argv();
    PyVal *ns = py_dict_new();
    size_t i, j;
    (void)kw;
    for (j = 0; j < py_len(opts); j++) {
        PyVal *spec = py_getitem(opts, py_int((int64_t)j));
        PyVal *name = py_getattr(spec, "name");
        PyVal *def = py_getattr(spec, "default");
        const char *nm = py_cstr(name);
        const char *dest = nm ? nm : "";
        while (*dest == '-') dest++;
        py_dict_put(ns, dest, def);
        py_release(spec); py_release(name); py_release(def);
    }
    for (i = 1; i < py_len(argv); i++) {
        PyVal *tok = py_getitem(argv, py_int((int64_t)i));
        const char *t = py_cstr(tok);
        int matched = 0;
        for (j = 0; j < py_len(opts); j++) {
            PyVal *spec = py_getitem(opts, py_int((int64_t)j));
            PyVal *name = py_getattr(spec, "name");
            const char *nm = py_cstr(name);
            if (nm && t && !strcmp(nm, t)) {
                PyVal *action = py_getattr(spec, "action");
                const char *act = py_cstr(action);
                const char *dest = nm;
                while (*dest == '-') dest++;
                if (act && !strcmp(act, "store_true")) {
                    py_dict_put(ns, dest, py_bool(1));
                } else if (i + 1 < py_len(argv)) {
                    PyVal *val = py_getitem(argv, py_int((int64_t)(++i)));
                    PyVal *tp = py_getattr(spec, "type");
                    PyVal *converted = val;
                    if (tp->type == PY_T_FUNC || tp->type == PY_T_BOUND ||
                        tp->type == PY_T_MODFUNC || tp->type == PY_T_CLASS) {
                        PyVal *av[1];
                        av[0] = val;
                        converted = py_call(tp, av, 1, NULL);
                        py_release(val);
                    } else {
                        const char *tname = py_cstr(tp);
                        if (tname && !strcmp(tname, "int")) {
                            converted = py_builtin_int(&val, 1, NULL);
                            py_release(val);
                        } else if (tname && !strcmp(tname, "float")) {
                            converted = py_builtin_float(&val, 1, NULL);
                            py_release(val);
                        }
                    }
                    py_dict_put(ns, dest, converted);
                    py_release(converted);
                    py_release(tp);
                }
                py_release(action);
                matched = 1;
                py_release(spec); py_release(name);
                break;
            }
            py_release(spec); py_release(name);
        }
        (void)matched;
        py_release(tok);
    }
    py_release(opts);
    return ns;
}

static PyVal *m311_argparse(PyVal **a, size_t n, PyVal *kw) {
    PyVal *methods = py_dict_new(), *cls, *parser;
    (void)a; (void)n; (void)kw;
    py_dict_put(methods, "add_argument", py_func(ap_add_argument, "add_argument"));
    py_dict_put(methods, "parse_args", py_func(ap_parse_args, "parse_args"));
    cls = py_class(methods, "ArgumentParser");
    py_release(methods);
    parser = py_call(cls, NULL, 0, NULL);
    py_release(cls);
    py_setattr(parser, "options", py_list_new());
    return parser;
}

PyVal *py311_module_call(const char *module, const char *name, PyVal **a,
                         size_t n, PyVal *kw, int *handled) {
    if (!handled) return NULL;
    *handled = 0;
    if (!py311_is_stdlib_module(module)) return NULL;
    *handled = 1;
    if (e311(module, "nturl2path")) {
        if (e311(name, "url2pathname") || e311(name, "pathname2url"))
            return e311(name, "url2pathname") ? m311_url2path(a, n, kw)
                                              : m311_path2url(a, n, kw);
    }
    if (e311(module, "pipes") || e311(module, "pipes.quote")) {
        if (e311(name, "quote") || e311(name, "quotepipe") ||
            e311(name, "quotemac") || e311(name, "quoteperl"))
            return m311_quote(a, n, kw);
    }
    if (e311(module, "ipaddress")) {
        if (e311(name, "ip_address") || e311(name, "IPv4Address"))
            return m311_ip(a, n, kw);
    }
    if (e311(module, "tty")) {
        if (e311(name, "setraw") || e311(name, "restore") ||
            e311(name, "cfmakeraw") || e311(name, "cfmakecbreak"))
            return m311_noop(a, n, kw);
    }
    if (e311(module, "antigravity") && e311(name, "main")) {
        fputs("https://xkcd.com/353/\n", stdout);
        return py_none();
    }
    if (e311(module, "gzip")) {
        if (e311(name, "compress")) return m311_gzip_compress(a, n, kw);
        if (e311(name, "decompress")) return m311_gzip_decompress(a, n, kw);
    }
    if (e311(module, "string") && e311(name, "capwords"))
        return m311_capwords(a, n, kw);
    if (e311(module, "argparse")) {
        if (e311(name, "ArgumentParser")) return m311_argparse(a, n, kw);
    }
    {
        char msg[512];
        snprintf(msg, sizeof(msg),
                 "stdlib module '%s' has no compiled implementation of '%s'",
                 module ? module : "", name ? name : "");
        py_raise(PY_EXC_UNSUPPORTED, msg);
    }
    return py_none();
}
'''


def main():
    text = BODY
    text = text.replace("@@BUILTINS@@", c_array("B311", [
        c_string(n) for n in BUILTIN_NAMES]))
    text = text.replace("@@MODULES@@", c_array("M311", [
        c_string(n) for n in STDLIB_MODULES]))
    text = text.replace("@@EXCEPTIONS@@", c_array("E311", [
        c_string(n) for n in EXCEPTION_NAMES]))
    text = text.replace("@@ALIASES@@", "\n".join(
        "    { %s, %s }," % (c_string(k), c_string(v))
        for k, v in sorted(ALIASES.items())))
    text = text.replace("@@ZEN@@", c_string(ZEN))
    OUT.write_text(text, encoding="utf-8", newline="\n")
    print("wrote %s (%d builtins, %d modules, %d aliases, %d exceptions)" %
          (OUT, len(BUILTIN_NAMES), len(STDLIB_MODULES), len(ALIASES),
           len(EXCEPTION_NAMES)))


if __name__ == "__main__":
    main()
