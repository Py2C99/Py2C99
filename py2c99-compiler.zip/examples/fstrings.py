x = 42
w = 5
p = 2
s = "héllo"
d = {"k": 7}
print(f"{x=}")
print(f"{s!r}")
print(f"{s!a}")
print(f"{x:0{w}d}")
print(f"{3.14159:.{p}f}")
print(f"{x=:{w}d}")
print(f"{d['k']}")
print(format(x, "+d"), format(x, "*>5d"), format(x, "^5d"), format(-42, "=6d"))
print(format("abcdef", ".2"), format(1234567, ","), format(42, "#b"), format(42, "#X"))
print(format(0.125, ".1%"), format(1, "05d"), format(-1, "=05d"))
