import ntpath
import posixpath
import genericpath
import html.entities
import email

print(ntpath.basename("a\\b\\c.txt"))
print(ntpath.join("a", "b", "c.txt"))
print(posixpath.basename("a/b/c.txt"))
print(posixpath.join("a", "b", "c.txt"))
print(genericpath.exists("__definitely_missing__"))
print(html.entities.html5["amp;"], html.entities.html5["copy"])
print(html.entities.entitydefs["euro"], html.entities.name2codepoint["amp"])
print(html.entities.codepoint2name[169])
msg = email.message_from_string("Subject: hi\r\nX-Test: yes\r\n\r\nbody text")
print(msg["Subject"], msg["X-Test"], msg["body"])
