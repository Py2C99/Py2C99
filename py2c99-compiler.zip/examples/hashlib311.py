import hashlib
import hmac

for data in [b"", b"abc", b"a" * 55, b"a" * 56, b"a" * 1000]:
    print(hashlib.md5(data).hexdigest())
    print(hashlib.sha1(data).hexdigest())
    print(hashlib.sha224(data).hexdigest())
    print(hashlib.sha256(data).hexdigest())
    print(hashlib.sha384(data).hexdigest())
    print(hashlib.sha512(data).hexdigest())
print(hashlib.new("sha256", b"abc").hexdigest())
h = hashlib.md5(b"abc")
h.update(b"def")
print(h.hexdigest())
print(h.copy().hexdigest())
print(hmac.new(b"key", b"msg", hashlib.sha256).hexdigest())
print(hmac.new(b"key", b"msg", hashlib.md5).hexdigest())
