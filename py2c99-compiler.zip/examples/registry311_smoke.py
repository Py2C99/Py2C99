import sys
import builtins
import _json
import ipaddress
import pipes
import gzip
import string
import argparse

d = dir(builtins)
print(len(d))
print("complex" in d)
print(builtins.__debug__)
print(builtins.ValueError)
print(complex(1, 2))
print(sys.stdlib_module_names[:3])
print(_json.dumps({"a": 1}))
print(pipes.quote("a b"))
print(ipaddress.ip_address("127.0.0.1"))
print(__import__("json").dumps([1, 2]))
print(gzip.decompress(gzip.compress("hello gzip")))
print(string.capwords("hello   WORLD"))
p = argparse.ArgumentParser()
p.add_argument("--count", type=int, default=0)
print(p.parse_args(["prog", "--count", "7"]))
