print(getattr({"a": 1}, "b", "fallback"))
it = iter([1, 2, 3])
print(next(it), next(it), next(it))
calls = []


def f():
    calls.append(1)
    return 2 if len(calls) < 3 else 99


print(list(iter(f, 2)), len(calls))
print(ord("A"), chr(66))
try:
    int("12x")
except ValueError as e:
    print(type(e).__name__)
try:
    ord("ab")
except TypeError as e:
    print(type(e).__name__)
print(pow(2, 10, 1000), pow(-2, 3, 5))
print(min([], default=9), max([], default=-9))
print(sum([1, 2, 3], start=10))
print(callable(print), callable(3))
print(sorted([3, 1, 2], key=lambda x: -x))
print(min(3, 1, 2), max(3, 1, 2))
try:
    getattr(3, "missing")
except AttributeError as e:
    print(type(e).__name__)
print("debug", __debug__)
print(sorted(dir({"x": 1}))[-1])


class C:
    a = 7

    def m(self):
        return self.a


c = C()
print(vars(C).get("a"), callable(c.m), c.m())
